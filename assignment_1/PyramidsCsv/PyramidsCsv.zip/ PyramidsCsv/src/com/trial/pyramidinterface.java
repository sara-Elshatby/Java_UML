package com.trial;

import java.util.List;

public interface pyramidinterface {
    public List<pyramid> readPyramidFromCSV(String filename);
    public pyramid creatPyramid(String[] metadata);


}
