package com.trial;

import java.io.IOException;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {
        // write your code here
        pyramidCsvDao pDao = new pyramidCsvDao();
        List<pyramid> pyramids = pDao.readPyramidFromCSV("C:\\pyramids.csv");
        int i = 0;
        for (pyramid p : pyramids) {
            System.out.println("#" + (i++) + p);
        }
    }
}
